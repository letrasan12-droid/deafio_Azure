# Desafio: Azure MySQL + Power BI + Power Query (by Manoel)
