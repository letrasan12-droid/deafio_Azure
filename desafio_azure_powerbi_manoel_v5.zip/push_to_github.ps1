Param([Parameter(Mandatory=$true)][string]$RepoUrl,[string]$Branch="main")
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {Write-Error 'git não encontrado'; exit 1}
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path; Set-Location $ScriptDir
& git init | Out-Null; try { & git checkout -b $Branch | Out-Null } catch {}
& git add .; try { & git commit -m 'Initial commit: Azure MySQL + Power BI challenge' | Out-Null } catch {}
& git branch -M $Branch | Out-Null; try { & git remote remove origin | Out-Null } catch {}
& git remote add origin $RepoUrl | Out-Null; & git push -u origin $Branch
Write-Host Concluído
