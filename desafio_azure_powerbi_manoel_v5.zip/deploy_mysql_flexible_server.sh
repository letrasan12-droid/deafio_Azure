#!/usr/bin/env bash
set -euo pipefail
RESOURCE_GROUP="rg-desafio-mysql"
LOCATION="brazilsouth"
SERVER_NAME="mysql-desafio-$$"
ADMIN_USER="manoel"
ADMIN_PASSWORD="Troque-esta-Senha!123"
PUBLIC_ACCESS_IP="SEU_IP_PUBLICO"
DB_NAME="desafio_powerbi"
SKU_NAME="B_Standard_B1ms"
az group create --name "$RESOURCE_GROUP" --location "$LOCATION"
az mysql flexible-server create   --resource-group "$RESOURCE_GROUP"   --name "$SERVER_NAME"   --location "$LOCATION"   --admin-user "$ADMIN_USER"   --admin-password "$ADMIN_PASSWORD"   --sku-name "$SKU_NAME"   --public-access "$PUBLIC_ACCESS_IP"
az mysql flexible-server db create   --resource-group "$RESOURCE_GROUP"   --server-name "$SERVER_NAME"   --database-name "$DB_NAME"
