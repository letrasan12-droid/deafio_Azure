#!/usr/bin/env bash
set -euo pipefail
if ! command -v git >/dev/null 2>&1; then echo "Erro: git não encontrado."; exit 1; fi
if [ $# -lt 1 ]; then echo "Uso: ./push_to_github.sh <REPO_URL> [BRANCH]"; exit 1; fi
REPO_URL="$1"; BRANCH="${2:-main}"; SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"; cd "$SCRIPT_DIR"
git init; (git checkout -b "$BRANCH") || true
git add .; git commit -m "Initial commit: Azure MySQL + Power BI challenge" || true
git branch -M "$BRANCH"; git remote remove origin 2>/dev/null || true; git remote add origin "$REPO_URL"
git push -u origin "$BRANCH"
echo Concluído
